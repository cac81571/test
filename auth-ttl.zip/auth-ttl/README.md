# 認証Cookieを一定時間だけ使い回す JMeter サンプル

SSO ログインはスレッドごとに、Cookie の有効期限が切れるまで実行しない。
期限が過ぎたループでだけ再認証する。

## 起動
    docker compose up -d
    # http://localhost:8090

- ユーザー: user001 / pass001、user002 / pass002（スレッド番号に対応）
- SSO_TOKEN のサーバ側有効期限: 20秒（docker-compose.yml の TOKEN_TTL）
- 未認証や期限切れの /app/ は /sso/login へ 302

## JMeter
    jmeter -n -t auth_ttl.jmx -l result.jtl -Jhost=localhost -Jport=8090 -Jthreads=2 -Jduration=60 -JauthTtlMs=15000

authTtlMs は JMeter が認証をやり直すまでのミリ秒。サーバの TOKEN_TTL より短くする。

## 確認
    curl http://localhost:8090/sso/stats
login が増えるのは期限切れのときだけ。業務リクエストのたびに増えたら、If Controller が毎回真になっている。
