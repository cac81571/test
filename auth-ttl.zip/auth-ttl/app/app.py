import uuid, threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlparse

sessions = {}
lock = threading.Lock()

class H(BaseHTTPRequestHandler):
    def reply(self, code, body, headers=None):
        self.send_response(code)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode())

    def do_GET(self):
        user = self.headers.get("X-Remote-User")
        if not user:
            return self.reply(403, "no user\n")
        c = SimpleCookie(self.headers.get("Cookie", ""))
        sid = c["JSESSIONID"].value if "JSESSIONID" in c else None
        headers = {}
        with lock:
            if sid not in sessions:
                sid = uuid.uuid4().hex[:12].upper()
                sessions[sid] = {"user": user, "hits": 0}
                headers["Set-Cookie"] = f"JSESSIONID={sid}; Path=/app; HttpOnly"
            sessions[sid]["hits"] += 1
            hits = sessions[sid]["hits"]
        self.reply(200, f"page={urlparse(self.path).path}\nuser={user}\nJSESSIONID={sid}\nhits={hits}\n", headers)

    def log_message(self, *a):
        pass

ThreadingHTTPServer(("0.0.0.0", 8080), H).serve_forever()
