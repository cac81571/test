import os, time, threading, secrets
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from urllib.parse import urlparse, parse_qs

COOKIE = os.environ.get("COOKIE_NAME", "SSO_TOKEN")
TTL = int(os.environ.get("TOKEN_TTL", "20"))
USERS = dict(p.split(":", 1) for p in os.environ.get("VALID_USERS", "user001:pass001").split(","))
tokens = {}  # token -> (user, exp)
lock = threading.Lock()
stats = {"login": 0, "validate_ok": 0, "validate_ng": 0}

class H(BaseHTTPRequestHandler):
    def send(self, code, body="", headers=None):
        self.send_response(code)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode())

    def do_POST(self):
        if urlparse(self.path).path != "/sso/login":
            return self.send(404, "not found\n")
        n = int(self.headers.get("Content-Length", "0"))
        q = parse_qs(self.rfile.read(n).decode())
        user, pw = q.get("user", [""])[0], q.get("password", [""])[0]
        with lock:
            stats["login"] += 1
        if USERS.get(user) != pw:
            return self.send(401, "login failed\n")
        tok = secrets.token_hex(8)
        with lock:
            tokens[tok] = (user, time.time() + TTL)
        self.send(200, f"user={user}\n", {"Set-Cookie": f"{COOKIE}={tok}; Path=/; HttpOnly"})

    def do_GET(self):
        u = urlparse(self.path)
        if u.path == "/validate":
            c = SimpleCookie(self.headers.get("Cookie", ""))
            tok = c[COOKIE].value if COOKIE in c else ""
            with lock:
                rec = tokens.get(tok)
                ok = rec is not None and rec[1] > time.time()
                if ok:
                    stats["validate_ok"] += 1
                    user = rec[0]
                else:
                    stats["validate_ng"] += 1
            if ok:
                return self.send(200, "", {"X-Remote-User": user})
            return self.send(401)
        if u.path == "/sso/stats":
            with lock:
                body = "\n".join(f"{k}={v}" for k, v in stats.items())
            return self.send(200, body + f"\nttl={TTL}\n")
        self.send(404, "not found\n")

    def log_message(self, fmt, *a):
        print("[sso]", fmt % a, flush=True)

ThreadingHTTPServer(("0.0.0.0", 8081), H).serve_forever()
